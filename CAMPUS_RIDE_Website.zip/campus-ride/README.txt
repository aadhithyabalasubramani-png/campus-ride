CAMPUS RIDE — SOFTWARE-ONLY DEMO

Open index.html in a modern browser. Internet access is required for Google Fonts, Leaflet, and OpenStreetMap tiles.

Features:
- Student overview dashboard
- Simulated live bus map and ETA
- Interactive 40-seat bus layout and local seat reservation
- Routes and stops with search
- Bus schedule
- Notifications
- Admin fleet management (add/remove demo buses)
- Driver console with start/end trip simulation
- Responsive desktop and mobile layout
- Dark-mode toggle

Important limitations:
All buses, locations, ETAs, routes, schedules, and occupancy values are demo data. No GPS, sensors, actual college fleet, backend, persistent database, or secure authentication is connected. Reservations and fleet edits exist only in the current browser session. Map tiles require internet.

For production deployment, connect a backend such as Supabase or Firebase and enforce booking uniqueness server-side.
